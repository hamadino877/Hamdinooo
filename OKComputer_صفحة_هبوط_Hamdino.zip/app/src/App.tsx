import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import About from './sections/About';
import ServicesExisting from './sections/ServicesExisting';
import ServicesNew from './sections/ServicesNew';
import AiCapabilities from './sections/AiCapabilities';
import HowItWorks from './sections/HowItWorks';
import Testimonials from './sections/Testimonials';
import CTA from './sections/CTA';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-navy text-white font-cairo antialiased overflow-x-hidden">
      <Navigation />
      <main>
        <Hero />
        <About />
        <ServicesExisting />
        <ServicesNew />
        <AiCapabilities />
        <HowItWorks />
        <Testimonials />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}

export default App;
