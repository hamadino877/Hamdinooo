import { Phone, MessageCircle, Sparkles } from 'lucide-react';

const footerLinks = [
  { text: 'الرئيسية', href: '#hero' },
  { text: 'الخدمات', href: '#services-existing' },
  { text: 'كيف يعمل', href: '#how-it-works' },
  { text: 'الشهادات', href: '#testimonials' },
  { text: 'تواصل معنا', href: '#cta' },
];

export default function Footer() {
  const handleLinkClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="relative bg-navy-dark border-t border-gold/10">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <a href="#hero" onClick={(e) => { e.preventDefault(); handleLinkClick('#hero'); }} className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gold/15 border border-gold/30 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-gold" />
              </div>
              <span className="text-xl font-bold text-white">Hamdino</span>
            </a>
            <p className="text-white/70 text-sm leading-relaxed mb-6">
              مستشارك الذكي في عالم المطاعم والتجارة
            </p>
            <div className="flex items-center gap-4">
              <a
                href="tel:+971586020247"
                className="w-10 h-10 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold hover:bg-gold/20 transition-colors"
              >
                <Phone className="w-5 h-5" />
              </a>
              <a
                href="https://wa.me/971586020247"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold hover:bg-gold/20 transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-6">روابط سريعة</h3>
            <ul className="space-y-3">
              {footerLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleLinkClick(link.href);
                    }}
                    className="text-white/70 hover:text-gold transition-colors text-sm"
                  >
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold mb-6">تواصل معنا</h3>
            <div className="space-y-4">
              <a
                href="tel:+971586020247"
                className="flex items-center gap-3 text-white/70 hover:text-gold transition-colors"
              >
                <Phone className="w-5 h-5 text-gold" />
                <span className="text-sm">+971 58 602 0247</span>
              </a>
              <a
                href="https://wa.me/971586020247"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-white/70 hover:text-gold transition-colors"
              >
                <MessageCircle className="w-5 h-5 text-gold" />
                <span className="text-sm">058 602 0247</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gold/10 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/50 text-sm">
            © 2025 Hamdino. جميع الحقوق محفوظة.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-white/50 hover:text-gold transition-colors text-sm">
              سياسة الخصوصية
            </a>
            <a href="#" className="text-white/50 hover:text-gold transition-colors text-sm">
              شروط الاستخدام
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
