import { useEffect, useRef, useState } from 'react';
import { Smartphone, Target, FileCheck, TrendingUp } from 'lucide-react';

const steps = [
  {
    number: '01',
    icon: Smartphone,
    title: 'حمل التطبيق',
    description: 'سجل حسابك في دقائق وأدخل بيانات مشروعك بشكل بسيط ومباشر',
  },
  {
    number: '02',
    icon: Target,
    title: 'حدد أهدافك',
    description: 'اختر ما تريد تحقيقه—زيادة المبيعات، إطلاق مشروع جديد، أو تحسين التشغيل',
  },
  {
    number: '03',
    icon: FileCheck,
    title: 'احصل على خطة مخصصة',
    description: 'يقوم الذكاء الاصطناعي بتحليل بياناتك وإعداد خطة عمل مفصلة ومخصصة',
  },
  {
    number: '04',
    icon: TrendingUp,
    title: 'نفذ وتابع التقدم',
    description: 'اتبع الخطوات الموصى بها وتابع تقدمك مع المستشار الذكي بشكل مستمر',
  },
];

export default function HowItWorks() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="how-it-works"
      ref={sectionRef}
      className="relative py-20 md:py-28 bg-navy overflow-hidden"
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/15 border border-gold/30 mb-6 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            <span className="text-gold text-sm font-medium">كيف يعمل</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            أربع خطوات بسيطة لتحقيق النجاح
          </h2>
          <p className={`text-lg text-white/85 max-w-2xl mx-auto transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            ابدأ رحلتك مع حمضنو بخطوات واضحة ومدروسة
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connector line - desktop only */}
          <div className="hidden lg:block absolute top-20 left-[12.5%] right-[12.5%] h-0.5 bg-gradient-to-r from-transparent via-gold/30 to-transparent" />

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
            {steps.map((step, index) => (
              <div
                key={step.number}
                className={`relative text-center transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${index * 150 + 300}ms` }}
              >
                {/* Number + Icon */}
                <div className="relative inline-flex flex-col items-center mb-6">
                  <div className="w-20 h-20 rounded-2xl bg-gold/15 border border-gold/30 flex items-center justify-center mb-3">
                    <step.icon className="w-8 h-8 text-gold" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-gold/20 border border-gold/40 flex items-center justify-center">
                    <span className="text-gold text-xs font-bold">{step.number}</span>
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-xl font-semibold text-white mb-3">{step.title}</h3>

                {/* Description */}
                <p className="text-white/70 leading-relaxed text-sm">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
