import { useEffect, useRef, useState } from 'react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    quote: 'حمضنو غير قواعد اللعب بالنسبة لمطعمي. خلال ثلاثة أشهر فقط، زادت مبيعاتنا بنسبة 40% بعد تطبيق توصيات المستشار الذكي لتحسين القائمة والتسعير.',
    author: 'أحمد الشامسي',
    title: 'صاحب مطعم، دبي',
    rating: 5,
  },
  {
    quote: 'كنت أحلم بإطلاق مطبخ سحابي لكن لم أكن أعرف من أين أبدأ. حمضنو قدم لي خطة عمل كاملة وساعدني في الربط مع منصات التوصيل. اليوم مشروعي يحقق ربحاً شهرياً مستقراً.',
    author: 'خالد المازمي',
    title: 'رائد أعمال، أبوظبي',
    rating: 5,
  },
  {
    quote: 'ما يميز حمضنو هو التخصص في سوق F&B بالإمارات. المستشار يفهم تحدياتنا المحلية ويقدم حلولاً عملية وليست نظريات عامة. أفضل استثمار قمت به لمطعمي.',
    author: 'فاطمة الحوسني',
    title: 'مالكة مجموعة مطاعم، الشارقة',
    rating: 5,
  },
];

export default function Testimonials() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="testimonials"
      ref={sectionRef}
      className="relative py-20 md:py-28 overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #1A2744 0%, #0F1923 100%)',
      }}
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/15 border border-gold/30 mb-6 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            <span className="text-gold text-sm font-medium">قصص النجاح</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            شهادات من رواد الأعمال الناجحين
          </h2>
          <p className={`text-lg text-white/85 max-w-2xl mx-auto transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            اقرأ تجارب حقيقية لأصحاب مطاعم حققوا نجاحاً ملحوظاً بمساعدة حمضنو
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.author}
              className={`glass-card-hover p-8 transition-all duration-700 relative ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 150 + 300}ms` }}
            >
              {/* Quote Icon */}
              <div className="absolute top-6 left-6 opacity-10">
                <Quote className="w-12 h-12 text-gold" />
              </div>

              {/* Rating */}
              <div className="flex items-center gap-1 mb-6">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-gold fill-gold" />
                ))}
              </div>

              {/* Quote Text */}
              <p className="text-white leading-relaxed mb-8 text-base">
                {testimonial.quote}
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gold/20 border border-gold/30 flex items-center justify-center">
                  <span className="text-gold font-semibold text-lg">
                    {testimonial.author.charAt(0)}
                  </span>
                </div>
                <div>
                  <div className="text-white font-semibold">{testimonial.author}</div>
                  <div className="text-white/70 text-sm">{testimonial.title}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}