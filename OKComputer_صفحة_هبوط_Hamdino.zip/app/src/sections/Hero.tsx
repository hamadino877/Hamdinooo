import { useEffect, useRef } from 'react';
import { Sparkles, ArrowLeft, Utensils, Brain, ChevronDown } from 'lucide-react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
}

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const particles: Particle[] = [];
    const particleCount = 40;
    const connectionDistance = 150;
    const goldColor = 'rgba(201, 168, 76, 0.6)';

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const createParticles = () => {
      particles.length = 0;
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          size: Math.random() * 2 + 1,
        });
      }
    };

    const drawParticles = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Update and draw particles
      particles.forEach((particle) => {
        particle.x += particle.vx;
        particle.y += particle.vy;

        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = goldColor;
        ctx.fill();
      });

      // Draw connections
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < connectionDistance) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(201, 168, 76, ${0.15 * (1 - distance / connectionDistance)})`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }

      animationId = requestAnimationFrame(drawParticles);
    };

    resize();
    createParticles();
    drawParticles();

    window.addEventListener('resize', () => {
      resize();
      createParticles();
    });

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #0F1923 0%, #1A2744 100%)',
      }}
    >
      {/* Particle Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ opacity: 0.8 }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/15 border border-gold/30 mb-8 animate-fade-in-up opacity-0">
          <Sparkles className="w-4 h-4 text-gold" />
          <span className="text-gold text-sm font-medium">
            تطبيق مستشار الأعمال المدعوم بالذكاء الاصطناعي
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight animate-fade-in-up opacity-0 animate-delay-200">
          حمضنو: الحل الذكي لريادة المطاعم في الإمارات
        </h1>

        {/* Description */}
        <p className="text-lg sm:text-xl text-white/85 mb-10 max-w-3xl mx-auto leading-relaxed animate-fade-in-up opacity-0 animate-delay-400">
          تطبيق متخصص يوفر لك استشارات مخصصة مدعومة بالذكاء الاصطناعي لتطوير مطعمك أو مشروعك الغذائي في الإمارات. من إنشاء خطة العمل إلى ربطك بمنصات التوصيل—كل ما تحتاجه لتحقيق النجاح.
        </p>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up opacity-0 animate-delay-600">
          <a
            href="#cta"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#cta')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="btn-primary flex items-center gap-2 group"
          >
            <span>ابدأ رحلتك الآن</span>
            <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
          </a>
          <a
            href="#services-existing"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#services-existing')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="btn-outline"
          >
            تعرف على الخدمات
          </a>
        </div>
      </div>

      {/* Floating Stats Cards */}
      <div className="hidden lg:block">
        <div
          className="absolute top-[15%] right-[5%] glass-card p-5 animate-float opacity-0 animate-fade-in-up animate-delay-800"
          style={{ animationDelay: '0.8s', animationFillMode: 'forwards' }}
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gold/15 flex items-center justify-center">
              <Utensils className="w-6 h-6 text-gold" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">+500</div>
              <div className="text-sm text-white/70">مطعم ناجح</div>
            </div>
          </div>
        </div>

        <div
          className="absolute bottom-[20%] left-[8%] glass-card p-5 animate-float-slow opacity-0 animate-fade-in-up"
          style={{ animationDelay: '1s', animationFillMode: 'forwards' }}
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gold/15 flex items-center justify-center">
              <Brain className="w-6 h-6 text-gold" />
            </div>
            <div>
              <div className="text-2xl font-bold text-white">AI</div>
              <div className="text-sm text-white/70">مستشار ذكي</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-6 h-6 text-gold/60" />
      </div>
    </section>
  );
}
