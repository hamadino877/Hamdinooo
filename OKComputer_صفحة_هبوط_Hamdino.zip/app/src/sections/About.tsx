import { useEffect, useRef, useState } from 'react';
import { ChefHat, Bot, TrendingUp } from 'lucide-react';

const features = [
  {
    icon: ChefHat,
    title: 'خبرة في F&B',
    description: 'فريق متخصص في قطاع المطاعم والتجارة الغذائية بالإمارات',
  },
  {
    icon: Bot,
    title: 'ذكاء اصطناعي متقدم',
    description: 'تقنيات AI حديثة تحلل بياناتك وتقدم توصيات دقيقة',
  },
  {
    icon: TrendingUp,
    title: 'نتائج قابلة للقياس',
    description: 'خطط عمل واضحة مع أهداف واضحة ومؤشرات أداء',
  },
];

export default function About() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-20 md:py-28 bg-navy overflow-hidden"
    >
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <div className={`transition-all duration-1000 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/15 border border-gold/30 mb-6">
              <span className="text-gold text-sm font-medium">من نحن</span>
            </div>

            {/* Headline */}
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
              شريكك الذكي في عالم المطاعم والتجارة الغذائية
            </h2>

            {/* Description */}
            <p className="text-lg text-white/85 mb-10 leading-relaxed">
              حمضنو هو تطبيق استشارات تجارية مدعوم بالذكاء الاصطناعي، مصمم خصيصاً لأصحاب المطاعم ورائدي الأعمال في قطاع الأغذية والمشروبات بالإمارات. نجمع بين الخبرة الصناعية العميقة والتقنيات المتقدمة لتقديم حلول عملية تحقق نتائج ملموسة.
            </p>

            {/* Features */}
            <div className="space-y-6 mb-8">
              {features.map((feature, index) => (
                <div
                  key={feature.title}
                  className={`flex items-start gap-4 transition-all duration-700 ${
                    isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
                  }`}
                  style={{ transitionDelay: `${index * 150 + 300}ms` }}
                >
                  <div className="w-12 h-12 rounded-xl bg-gold/15 flex items-center justify-center shrink-0">
                    <feature.icon className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">{feature.title}</h3>
                    <p className="text-white/70 text-sm">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Button */}
            <a
              href="#services-existing"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#services-existing')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="btn-outline inline-block"
            >
              اكتشف المزيد
            </a>
          </div>

          {/* Image */}
          <div className={`transition-all duration-1000 delay-300 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
            <div className="relative">
              <img
                src="/assets/about-app.png"
                alt="واجهة تطبيق حمضنو الذكية"
                className="w-full rounded-2xl shadow-2xl"
                style={{ boxShadow: '0 20px 60px rgba(0,0,0,0.4)' }}
              />
              {/* Decorative glow */}
              <div className="absolute -inset-4 bg-gold/10 rounded-3xl blur-2xl -z-10" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
