import { useEffect, useRef, useState } from 'react';
import { ChartLine, AlertCircle, BookOpen, Users } from 'lucide-react';

const services = [
  {
    icon: ChartLine,
    title: 'زيادة المبيعات',
    description: 'استراتيجيات مدروسة لزيادة الإيرادات وتحسين متوسط قيمة الفاتورة',
  },
  {
    icon: AlertCircle,
    title: 'إصلاح الأخطاء التشغيلية',
    description: 'اكتشف المشاكل التشغيلية واحصل على حلول فورية لتحسين الكفاءة',
  },
  {
    icon: BookOpen,
    title: 'بناء قوائم الطعام',
    description: 'تصميم قوائم مربحة توازن بين التكلفة والجودة وتجربة العميل',
  },
  {
    icon: Users,
    title: 'تدريب الموظفين',
    description: 'برامج تدريب مخصصة لرفع كفاءة فريق العمل وتحسين الخدمة',
  },
];

export default function ServicesExisting() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="services-existing"
      ref={sectionRef}
      className="relative py-20 md:py-28 overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #1A2744 0%, #0F1923 100%)',
      }}
    >
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/15 border border-gold/30 mb-6 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            <span className="text-gold text-sm font-medium">لأصحاب المطاعم الحاليين</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            طور مطعمك وزد مبيعاتك
          </h2>
          <p className={`text-lg text-white/85 max-w-2xl mx-auto transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            حلول عملية لتحسين أداء مطعمك الحالي وزيادة ربحيته
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`glass-card-hover p-8 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 150 + 300}ms` }}
            >
              <div className="w-14 h-14 rounded-xl bg-gold/15 flex items-center justify-center mb-6">
                <service.icon className="w-7 h-7 text-gold" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
              <p className="text-white/70 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
