import { useEffect, useRef, useState } from 'react';
import { Rocket, FileText, Link, ChefHat, Map, ListChecks } from 'lucide-react';

const services = [
  {
    icon: Rocket,
    title: 'إطلاق المطاعم والمطابخ السحابية',
    description: 'خطوات عملية لإطلاق مشروعك من الفكرة إلى الافتتاح الرسمي',
  },
  {
    icon: FileText,
    title: 'إنشاء خطط العمل',
    description: 'خطط عمل احترافية تشمل الدراسة المالية والتسويقية والتشغيلية',
  },
  {
    icon: Link,
    title: 'الربط مع منصات التوصيل',
    description: 'تواصل مباشر مع طلبات، كريم، نون، كيتا، وغيرها من المنصات',
  },
  {
    icon: ChefHat,
    title: 'تطوير الوصفات',
    description: 'وصفات مبتكرة محسوبة التكلفة تتماشى مع ذوق السوق الإماراتي',
  },
  {
    icon: Map,
    title: 'خارطة طريق للربحية',
    description: 'خطة واضحة لتحقيق الربحية مع جدول زمني وأهداف قابلة للقياس',
  },
  {
    icon: ListChecks,
    title: 'خطط النجاح خطوة بخطوة',
    description: 'دليل عملي يأخذك بخطوات واضحة نحو إطلاق مشروع ناجح ومستدام',
  },
];

export default function ServicesNew() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="services-new"
      ref={sectionRef}
      className="relative py-20 md:py-28 bg-navy overflow-hidden"
    >
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/15 border border-gold/30 mb-6 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            <span className="text-gold text-sm font-medium">لرواد الأعمال الجدد</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            ابدأ مشروعك الغذائي من الصفر
          </h2>
          <p className={`text-lg text-white/85 max-w-2xl mx-auto transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            دليلك الشامل لإطلاق مطعم أو مطبخ سحابي ناجح في الإمارات
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`glass-card-hover p-8 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 100 + 300}ms` }}
            >
              <div className="w-14 h-14 rounded-xl bg-gold/15 flex items-center justify-center mb-6">
                <service.icon className="w-7 h-7 text-gold" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
              <p className="text-white/70 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
