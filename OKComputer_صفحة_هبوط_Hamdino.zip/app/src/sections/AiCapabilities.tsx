import { useEffect, useRef, useState } from 'react';
import { MessageSquare, BarChart3, Clock, ArrowLeft } from 'lucide-react';

const features = [
  {
    icon: MessageSquare,
    title: 'محادثة طبيعية',
    description: 'تحدث مع المستشار باللغة العربية بشكل طبيعي كأنك تتحدث مع خبير',
  },
  {
    icon: BarChart3,
    title: 'تحليلات ذكية',
    description: 'تحليل بياناتك واتجاهات السوق لتقديم رؤى قابلة للتنفيذ',
  },
  {
    icon: Clock,
    title: 'متاح 24/7',
    description: 'استشارات فورية في أي وقت، دون انتظار مواعيد أو اجتماعات',
  },
];

export default function AiCapabilities() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="ai-capabilities"
      ref={sectionRef}
      className="relative py-20 md:py-28 overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #1A2744 0%, #0F1923 100%)',
      }}
    >
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image - Left on desktop */}
          <div className={`order-2 lg:order-1 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
            <div className="relative">
              <img
                src="/assets/ai-consultant.png"
                alt="واجهة المستشار الذكي في تطبيق حمضنو"
                className="w-full rounded-2xl shadow-2xl"
                style={{ boxShadow: '0 20px 60px rgba(0,0,0,0.4)' }}
              />
              <div className="absolute -inset-4 bg-gold/10 rounded-3xl blur-2xl -z-10" />
            </div>
          </div>

          {/* Content - Right on desktop */}
          <div className={`order-1 lg:order-2 transition-all duration-1000 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/15 border border-gold/30 mb-6">
              <span className="text-gold text-sm font-medium">الذكاء الاصطناعي</span>
            </div>

            {/* Headline */}
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
              مستشار ذكي يفهم سوقك ويقدم حلولاً مخصصة
            </h2>

            {/* Description */}
            <p className="text-lg text-white/85 mb-10 leading-relaxed">
              يعتمد حمضنو على تقنيات الذكاء الاصطناعي المتقدمة لتحليل السوق الإماراتي وتقديم توصيات مخصصة بناءً على بياناتك وأهدافك. المستشار الذكي يتعلم من كل تفاعل ويقدم نصائح أكثر دقة مع الوقت.
            </p>

            {/* Features */}
            <div className="space-y-6 mb-10">
              {features.map((feature, index) => (
                <div
                  key={feature.title}
                  className={`flex items-start gap-4 transition-all duration-700 ${
                    isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
                  }`}
                  style={{ transitionDelay: `${index * 150 + 400}ms` }}
                >
                  <div className="w-12 h-12 rounded-xl bg-gold/15 flex items-center justify-center shrink-0">
                    <feature.icon className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">{feature.title}</h3>
                    <p className="text-white/70 text-sm">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Button */}
            <a
              href="#cta"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#cta')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="btn-primary flex items-center gap-2 group inline-flex"
            >
              <span>جرب المستشار الذكي</span>
              <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}