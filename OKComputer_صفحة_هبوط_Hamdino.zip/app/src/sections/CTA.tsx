import { useEffect, useRef, useState } from 'react';
import { MessageCircle, Phone } from 'lucide-react';

export default function CTA() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="cta"
      ref={sectionRef}
      className="relative py-24 md:py-32 overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #1A2744 0%, #0F1923 100%)',
      }}
    >
      <div className="max-w-[800px] mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`glass-card p-10 md:p-16 text-center transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/15 border border-gold/30 mb-8">
            <span className="text-gold text-sm font-medium">ابدأ الآن</span>
          </div>

          {/* Headline */}
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
            جاهز لتطوير مشروعك الغذائي؟
          </h2>

          {/* Description */}
          <p className="text-lg text-white/85 mb-10 max-w-xl mx-auto leading-relaxed">
            انضم إلى مئات أصحاب المطاعم الناجحين في الإمارات واحصل على مستشارك الذكي اليوم. التسجيل مجاني والاستشارة الأولى على حسابنا.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
            <a
              href="https://wa.me/971586020247"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary flex items-center gap-2 group w-full sm:w-auto justify-center"
            >
              <MessageCircle className="w-5 h-5" />
              <span>تحدث معنا على واتساب</span>
            </a>
            <a
              href="tel:+971586020247"
              className="btn-outline flex items-center gap-2 group w-full sm:w-auto justify-center"
            >
              <Phone className="w-5 h-5" />
              <span>اتصل بنا</span>
            </a>
          </div>

          {/* Contact Info */}
          <div className="border-t border-gold/20 pt-8">
            <p className="text-white/70 text-sm mb-4">تواصل معنا مباشرة:</p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <a
                href="tel:+971586020247"
                className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
              >
                <Phone className="w-5 h-5" />
                <span className="text-lg font-semibold">+971 58 602 0247</span>
              </a>
              <a
                href="https://wa.me/971586020247"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
                <span className="text-lg font-semibold">058 602 0247</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold/5 rounded-full blur-3xl -z-10" />
    </section>
  );
}
